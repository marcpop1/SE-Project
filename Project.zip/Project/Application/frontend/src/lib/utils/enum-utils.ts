export class EnumUtils {
    enumToArray(enumObj: any): string[] {
        return Object.values(enumObj);
    }
}