from enum import Enum

class TransactionType(Enum):
    TOP_UP = "top-up"
    TRANSFER = "transfer"