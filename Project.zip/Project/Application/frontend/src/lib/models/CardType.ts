export enum CardType {
    VISA = 'Visa',
    MASTERCARD = 'MasterCard'
}