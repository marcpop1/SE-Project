export enum UserRole {
    USER = 'user',
    ADMIN = 'admin'
}