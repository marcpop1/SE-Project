export enum TransactionType {
    TOP_UP = 'top-up',
    TRANSFER = 'transfer'
}