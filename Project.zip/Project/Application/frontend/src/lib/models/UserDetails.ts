export interface UserDetails {
    id: number;
    username: string;
    name: string;
}