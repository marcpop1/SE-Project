export enum Currency {
    RON = "RON",
    EUR = "EUR",
    USD = "USD",
    GBP = "GBP"
}