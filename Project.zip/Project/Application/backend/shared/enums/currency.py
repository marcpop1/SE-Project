from enum import Enum

class Currency(Enum):
    RON = "RON"
    EUR = "EUR"
    USD = "USD"
    GBP = "GBP"